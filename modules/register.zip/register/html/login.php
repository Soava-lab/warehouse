<p>Login</p>
<form method="post">
    <input type="text" name="username">
    <input type="text" name="password">
	<input type="submit" name="doLogin" value="Login" />
</form>
