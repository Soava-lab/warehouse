<p>Sign Up</p>
<form method="post" action="signup">
    <p>Username: <input type="text" name="username" required></p>
    <p>Email: <input type="email" name="email" required></p>
    <p>Password: <input type="text" name="password" required></p>
    <p>Address: <input type="text" name="address" required></p>
	<input type="submit" name="doSubmit" value="Sign Up" />
</form>
